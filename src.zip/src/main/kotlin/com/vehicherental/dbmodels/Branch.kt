package com.vehicherental.dbmodels

data class Branch(private val branchName: String)
