package com.vehicherental.dbmodels

data class Vehicle(private val vehicleId: String, private val vehicleType: VehicleType, private val branchName: String)
