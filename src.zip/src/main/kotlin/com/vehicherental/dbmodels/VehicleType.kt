package com.vehicherental.dbmodels

enum class VehicleType {
    Sedan,
    Hatchback
}
