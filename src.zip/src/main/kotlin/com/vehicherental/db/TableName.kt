package com.vehicherental.db

enum class TableName {
    Booking,
    Branch,
    RentalPrice,
    Vehicle,
}
